<template>
    <div>
      <h1>{{title}}</h1>
      <button v-on:click="myfun">Click me</button>
      <!-- <button @click="myfun">Click me</button> -->
      <h1>{{power}}</h1>
      <button @click="power++">Increase Power</button> &nbsp;
      <button @click="power--">Decrease Power</button>
      <hr>
      <button @click="increasePower">Increase Power</button>
      <button @click="decreasePower">Decrease Power</button>
      <br>
      <input @input="setPower($event)" type="range">
      <!-- <button @click="setPower($event)">Decrease Power</button> -->
    </div>
  </template>
  
  <script>
  export default {
    data(){
      return {
        title:"Methods Events Computed",
        power:0
      }
    },
    methods:{
      myfun(){
        alert("Button was clicked")
      },
      increasePower(){
        this.power++
      },
      decreasePower(){
        this.power--
      },
      setPower(evt){
        this.power=evt.target.value
      }
    }
  }
  </script>
  
  <style>
  #app {
    font-family: Avenir, Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;
    margin-top: 60px;
  }
  </style>
  