<template>
  <div>
    <h1>{{title}}</h1>
    <pre>{{ JSON.stringify(heroinfo, null, 1) }}</pre>
    <form>
        <div class="mb-3">
            <label for="htitle" class="form-label">Hero Title</label>
            <input v-model="heroinfo.title" type="text" class="form-control" id="htitle">
        </div>
        <div class="mb-3">
            <label for="hfname" class="form-label">Hero First Name</label>
            <input v-model="heroinfo.firstname" type="text" class="form-control" id="hfname">
        </div>
        <div class="mb-3">
            <label for="hlname" class="form-label">Hero Last Name</label>
            <input v-model="heroinfo.lastname" type="text" class="form-control" id="hlname">
        </div>
        <div class="mb-3">
            <label for="hcity" class="form-label">Hero City</label>
            <input v-model="heroinfo.city" type="text" class="form-control" id="hcity">
        </div>
        <div class="mb-3">
            <label for="hpower" class="form-label">Hero Power</label>
            <input v-model="heroinfo.power" type="number" class="form-control" id="hpower">
        </div>
        <div class="mb-3">
            <label for="htype" class="form-label">Hero Type</label> &nbsp;
            <select v-model="heroinfo.type">
              <option value="" selected>Select Here</option>
              <option value="avenger" selected>Avenger</option>
              <option value="Justice_league" selected>Justice League</option>
              <option value="Indic_heros" selected>Indic Heros</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="hcf" class="form-label">Hero Can Fly</label> &nbsp;
            <input true-value="can fly" false-value="can't fly" v-model="heroinfo.canfly" type="checkbox" id="hcf">
        </div>
        <div class="mb-3">
          <label for="hgender" class="form-label">Hero Gender</label> &nbsp;
            <label for="hgenderm" class="form-label">Male</label>
            <input  v-model="heroinfo.gender" name="gen" value="male" type="radio" id="hgenderm"> &nbsp;
            <label for="hgenderf" class="form-label">Female</label>
            <input  v-model="heroinfo.gender" name="gen" value="female" type="radio" id="hgenderf">
        </div>
        
      <button type="submit" class="btn btn-primary">Register</button>
    </form>
  </div>
</template>

<script>
export default {
  data(){
    return {
      title:"Forms and Data",
      heroinfo : {
      title : '',
      firstname : '',
      lastname : '',
      city : '',
      power : 0,
      type : '',
      canfly:'',
      gender:''
    },
    }
  }
}
</script>

<style>
#app1 {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
