<template>
    <div>
      <h1>{{title}}</h1>
      <input min="0" max="10" type="number" v-model="power">
      <!-- <input min="0" max="10" type="range" v-model="power"> range - treated as string -->
      <!-- <h1 v-if="power===1">Power is 1</h1>
      <h1 v-if="power===2">Power is 2</h1>
      <h1 v-if="power===3 ">Power is 3</h1>
      <h1 v-if="power===4">Power is 4</h1> -->
      <h1 v-if="power===5">Power is 5</h1>
      <h1 v-else>Power is not 5</h1>
      <input type="checkbox" v-model="show">
      <template v-if="show"> <!--template tag only with if and else if-->
      
        <h2>Company Policy</h2>
        <fieldset>
          <legend>Terms and Conditions</legend>
          <p>
            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Harum autem, delectus ea qui nemo officia molestias! Harum magni, suscipit porro quos numquam iure tempore asperiores odit animi odio illum quasi.
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt, iste, delectus fugiat excepturi quidem blanditiis aspernatur laboriosam quisquam ut, sit explicabo molestias tenetur doloribus! Quo suscipit nesciunt amet? Ullam, optio?
          </p>
        </fieldset>
   
    </template>
  
    <h2 v-if="show">If Valtech</h2>
    <h2 v-show="show">Show Valtech</h2> <!--content creted but hidden-->
    </div>
  </template>
  
  <script>
  export default {
    data(){
      return {
        title:"App Vue Title",
        power:5,
        show:true
      }
    }
  }
  </script>
  
  <style>
  #app {
    font-family: Avenir, Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;
    margin-top: 60px;
  }
  </style>
  