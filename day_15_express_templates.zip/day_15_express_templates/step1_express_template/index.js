const express=require("express")
let app=express();
var port=process.env.PORT || 6000


//routes
// app.get("/",(req,res)=>{
//     res.sendFile(__dirname+"/public/index.html");
// });
// app.get("/about",(req,res)=>{
//     res.sendFile(__dirname+"/public/about.html");
// });
// app.get("/contact",(req,res)=>{
//     res.sendFile(__dirname+"/public/contact.html");
// });

// app.get("/",(req,res)=>{
//     res.render("index.ejs",{
//         compname:"Valtech",
//         message:"Have a nice day!",
//         people:['harshitha','sneha']
//     })
// });
// app.get("/about",(req,res)=>{
//     res.render("about.ejs",{
//         compname:"Valtech"
//     })
// });
// app.get("/contact",(req,res)=>{
//     res.render("contact.ejs",{
//         compname:"Valtech"
//     })
// });


// app.set("views","templates")//tells engine to check templates instead of views
// app.set("view engine","ejs")//

app.use(function(req,res,next){
    console.log("Custom Middleware",req.url);
    next();
})

function myfun(){
    console.log("get for home page received");
}

app.get("/",myfun,(req,res)=>{
    res.render("index.pug",{
        compname:"Valtech",
        message:"Have a nice day!",
        people:['harshitha','sneha']
    })
});
app.get("/about",(req,res)=>{
    res.render("about.pug",{
        compname:"Valtech"
    })
});
app.get("/contact",(req,res)=>{
    res.render("contact.pug",{
        compname:"Valtech"
    })
});

app.listen(5656,"localhost",function(error){
    if(error){
        console.log("Error ",error)
    }else{
        console.log(`server is now live on localhost :5656`)
    }
})