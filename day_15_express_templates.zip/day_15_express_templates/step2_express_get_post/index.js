const express=require("express")
let app=express()

var herolist=["Harshitha"];

app.use(express.urlencoded({extended:true}))

app.get("/",(req,res)=>{
    res.render("home.ejs",{
        compname:"Valtech",
        herolist
    });
});

app.post("/",(req,res)=>{
    herolist.push(req.body.nhero);
    res.redirect("/");
    res.end();
});

app.listen(2020,"localhost",function(error){
    if(error){
        console.log("Error",error);
    }else{
        console.log("server is now live on localhost:2020");
    }
})