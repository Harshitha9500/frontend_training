const express=require("express");
const mongoose=require("mongoose");
const cors=require("cors");

let app=express();
app.use(express.json());

let Schema=mongoose.Schema;
let ObjectId=Schema.ObjectId;
let url="mongodb+srv://admin:PkKmeqYPd5ipJmxN@cluster0.rk5sld5.mongodb.net/valtechdb?retryWrites=true&w=majority"

let Hero=mongoose.model("Hero",Schema({
    id:ObjectId,
    title:String,
    firstname:String,
    lastname:String
}));

mongoose.connect(url)
.then(function(){
    console.log("db connected");
})
.catch(function(err){
    console.log("Error",err)
});

app.get("/",function(req,res){
    Hero.find().then(dbres=>{
        res.json(dbres);
    })
})

app.listen(8080,"localhost",function(error){
    if(error){
        console.log("error ", error)
    }else{
        console.log("sever is now live on localhost:6060")
    }
})