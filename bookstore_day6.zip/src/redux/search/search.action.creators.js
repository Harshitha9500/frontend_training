import { SEARCH_BOOK } from "./search.types"

const searchbook=(book,college)=>{
    return{
        type:SEARCH_BOOK,
        payload:{book,college}
    }
}
// const searchcollege=(college)=>{
//     return{
//         type:SEARCH_COLLEGE,
//         payload:{college}

//     }
// }


// export {searchbook,searchcollege}
export {searchbook}