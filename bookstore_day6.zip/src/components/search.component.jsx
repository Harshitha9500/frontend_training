import { useSelector, useDispatch } from "react-redux";
// import { NavLink } from "react-router-dom";
import { searchbook } from "../redux/";
import React, { useState } from "react";
import { useRef } from "react";
let Search = () => {
  let[state,changeState]=useState({bookState:"", collegeState:""})
  var book = "";
  var college = "";
  var validate=true;
  let books = useSelector((state) => state.search.books);
  let colleges = useSelector((state) => state.search.colleges);
  let inputFeildBook = useRef()
  let inputFeildCollege = useRef()
  let ValidateCollege = useRef()
  let ValidateBook = useRef()
  // let searchByCollege = useSelector(state => state.search.searchByCollege);
  var bookSearch = [];
  var collegeSearch = [];
  Object.keys(books).forEach(function (item) {
    bookSearch.push(books[item]);
  });
  Object.keys(colleges).forEach(function (item) {
    collegeSearch.push(colleges[item]);
  });
  let dispatch = useDispatch();
  let setBook = (e) => {
    book = e.target.value;
    // changeState(e.target.value)
    // console.log(state)
  };
  let setCollege = (e) => {
    college = e.target.value;
    ValidateCollege.current="";
    
  };
  let clearValidate = ()=>{
    return ValidateBook.current=""
  }
  
  let clearSearch = () => {
    // console.log(inputFeildCollege.current.value)
    inputFeildBook.current.value=''
    inputFeildCollege.current.value=''
    if(inputFeildBook.current.value=='' && inputFeildCollege.current.value==''){
      ValidateCollege.current="Please Enter College";
      ValidateBook.current="Please Enter Book"
      validate=true
    }
    if(inputFeildBook.current.value!=='' || inputFeildCollege.current.value!==''){
      ValidateCollege.current="";
      ValidateBook.current=""
      validate=false
    }
  }


  return (
    <div id="searchbox">
      <div> 
        <div class="mb-1">
          <label for="college" class="form-label"></label>
          <input
            placeholder="Search By College"
            onChange={(e) => setCollege(e)}
            type="text"
            class="form-control"
            id="college"
            name="college"
            ref={inputFeildCollege}
          />
          {!validate&&<span style={{ color: "red", margin: "0px" }} >
            {ValidateCollege.current}
          </span>}
        </div>
        <div class="mb-2">
          <label for="book" class="form-label"></label>
          <input 
            placeholder="Search By Book"
            onChange={(e) => {setBook(e)
          clearValidate()
       }}
            type="text"
            class="form-control"
            id="book"
            name="book"
            ref={inputFeildBook}
          />
          {validate && <span style={{ color: "red", margin: "0px" }}>{ValidateBook.current}</span>}
        </div>
        {/* <NavLink to={"/search/"+book}> */}
        <button
          type="submit"
          onClick={() => {dispatch(searchbook(book,college))
          clearSearch()}}
          class="btn btn-primary"
        >
          Search
        </button>
        {/* </NavLink> */}
      </div>
    </div>
  );
};

export default Search;
