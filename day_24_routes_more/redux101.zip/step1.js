let redux=require("redux")
let createStore=redux.legacy_createStore;
// action type is a constant name
// action creator is a function that returns an action object
// reducer is a function which has switch cases to call funvtions based on action type
// initial state is an initial value of store object
// store is an object that stores all shared states of your application
// subscribe/unsubscribe to listen to changes of the store
// dispatch is a method that can take action object

//ACTION
const ADDHERO="ADDHERO"

//ACTION CREATOR
let addhero=function(){
    return {
        type:ADDHERO
    }
}

//initial-state
let initialstate={
    numberofHeros:0
}

//reducer
let reducer=(state=initialstate,action)=>{
    switch(action.type){
        case ADDHERO: return {numberofHeros:state.numberofHeros+1}
        default:return state
    }
}

let store=createStore(reducer);

console.log("initial value of store", store.getState());

let unsubscribe=store.subscribe(()=>console.log("Subscribed", store.getState()))

store.dispatch(addhero())
store.dispatch(addhero())
store.dispatch(addhero())
unsubscribe();
store.dispatch(addhero())
store.dispatch(addhero())
console.log(store.getState());


