const eventEmitter=require("events").EventEmitter
let myEvent = new eventEmitter();
myEvent.addListener("valtech",function(){
    console.log("valtech event happened")
});
setTimeout(function(){
    myEvent.emit("valtech")
},2000)

