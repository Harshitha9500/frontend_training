const http=require("http")

let server=http.createServer(function(req,res){
    res.writeHead(200,{"Content-Type":"text/plain"});
    res.write("<h1>Have a nice day!!</h1>");
    res.end();
});

server.listen(1010,"localhost",function(err){
    if(err){
        console.log("error",err)
    }else{
        console.log("server is now live on localhost:1010")
    }
})