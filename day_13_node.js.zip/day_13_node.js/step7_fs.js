var fs=require("fs");

//fs.writeFileSync("hello.txt","Hello!! Have a nice day","utf-8");
// fs.writeFile("hello.txt","Hello!! Have a nice day","utf-8",function(error,data){
// if(error){
//     console.log("error",error)
// }else{
//     console.log("file was created")
// }
// })

//console.log(fs.readFileSync("hello.txt","utf-8"));
// fs.readFile("hello.txt","utf-8",function(error,data){
//     if(error){
//         console.log("error",error)
//     }else{
//         console.log(data);
//     }
// })

fs.watchFile("hello.txt",function(error,data){
        console.log("file updated")  
})

setInterval(function(){
    fs.appendFile("hello.txt","\nHarshitha","utf-8",function(err,data){
        if(err){
            console.log("error",err)
        }else{
            console.log("content is added")
        }
    })
},2000)