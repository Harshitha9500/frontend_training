var obj=require("./step1_node")
console.log(obj.message1)
console.log(obj.message2)
console.log(obj.adder(5,4))