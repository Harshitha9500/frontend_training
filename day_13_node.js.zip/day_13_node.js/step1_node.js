var message1="Hello!" 
var message2="Have a nice day."
var adder=function(a,b){
    return a+b
}
// console.log(message)
// console.log(__dirname)
// console.log(__filename)

// module.exports.message1=message1
// module.exports.message2=message2

module.exports={message1,message2,adder}