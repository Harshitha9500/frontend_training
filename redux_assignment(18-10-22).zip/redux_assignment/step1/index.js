const fs = require("fs")
const process = require('process');
let redux = require("redux")
let createStore = redux.legacy_createStore;

let result = new Array()
let data = `Firstname ${process.argv[2]}\nLastname ${process.argv[3]}\nPower ${process.argv[4]}\n`
fs.appendFile("./data.txt",data, (err) => {
    if (err) {
      console.log(err);
    }
    else {
      
      console.log("\nValue : \n",
        fs.readFileSync("./data.txt", "utf8"));
    }
  })

  //ACTION
  const ADDHERO = "ADDHERO"

  //ACTION CREATOR
  let addhero = ()=>{
    return{
        type:ADDHERO
    }
}

//INITIAL STATE
let initialState={
    numberOfHeros:""
}

//REDUCER
let reducer = (state=initialState,action)=>{
    switch(action.type){
        case ADDHERO:  const data = fs.readFileSync('./data.txt', 'ascii');
                        result.push(data) 
                        return {numberOfHeros:result}
                        default: return state
    }
}

let store = createStore(reducer)
console.log("Initial value of store",store.getState())
let unsubscribe = store.subscribe(()=>console.log("Subscribed",store.getState()))

store.dispatch(addhero())
