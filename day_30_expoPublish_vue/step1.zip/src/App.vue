<template>
  <div>
    <h1>Title : {{title.toUpperCase()}}</h1>
    <h1>Age : {{age+5}}</h1>
    <hr>
    <h1 v-text="title"></h1>
    <h1 v-html="messagetag"></h1>
    <div v-bind:class="dynamicClass">
      Hello!!
    </div>
    <div v-bind:id="dynamicId">
      Hello!!
    </div>
    <button v-bind:disabled="show">Click</button>
    <input type="checkbox" v-model="show"/>
    <input type="text" v-model="title"/>
    <fieldset>
      <label for="Terms and condition">
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Odio, vel quisquam libero aliquam veniam iusto harum voluptate nam facere incidunt illum est nostrum laborum consequatur, non repudiandae provident dolore assumenda!
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore id inventore earum deleniti expedita fugiat dolor doloremque, qui nulla odio officia voluptas rem vitae sit rerum voluptates incidunt atque adipisci.
      </p>
    </label>
    </fieldset>
    <div v-bind:class="['box','borderbox']">
      Style with two classes
    </div>
    <div v-bind:class="{'pinkbox' : gender === 'female'}">
      Conditional style rendering
    </div>
  </div>

</template>

<script>
export default {
  name: 'App',
  components: {
  },
  data(){
    return {
      title:"Welcome to valtech",
      age:20,
      messagetag:"<span>Welcome to <u>your</u> <em>life</em></span>",
      dynamicClass:"box",
      dynamicId:"player",
      show:false,
      gender:"female"
    }
    
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #c3e020;
  margin-top: 60px;
}
#player{
  width:200px;
  height:200px;
  background-color: grey;
  text-align: center;
  line-height: 200px;
  margin: 10px;
}
.box{
  width:200px;
  height:200px;
  background-color: cadetblue;
  text-align: center;
  line-height: 200px;
  margin: 10px;
}
.borderbox{
  border:2px solid black;
}
.pinkbox{
  width:200px;
  height:200px;
  background-color: palevioletred;
  text-align: center;
  line-height: 200px;
  margin: 10px;
}
.bluebox{
  width:200px;
  height:200px;
  background-color: palevioletred;
  text-align: center;
  line-height: 200px;
  margin: 10px;
}
</style>
