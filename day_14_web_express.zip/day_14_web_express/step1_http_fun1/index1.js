const http=require("http");
const fs=require("fs");

let server=http.createServer((req,res)=>{
    if(req.url==="/" || req.url==="/index.html"){
        let htmlContent=fs.readFileSync("./index.html","utf-8");
        res.writeHead(200,{"Content-Type":"text/html"})
        res.write(htmlContent);
        res.end();
    }else if(req.url==="/about.html"){
        let htmlContent=fs.readFileSync("./about.html","utf-8");
        res.writeHead(200,{"Content-Type":"text/html"})
        res.write(htmlContent);
        res.end();
    }
    else if(req.url==="/contact.html"){
        let htmlContent=fs.readFileSync("./contact.html","utf-8");
        res.writeHead(200,{"Content-Type":"text/html"})
        res.write(htmlContent);
        res.end();
    }
});

server.listen(2020,"localhost",function(error,data){
    if(error){
        console.log("error",error);
    }
})

