const http=require("http");
const fs=require("fs");
var compname="Valtech"

let server=http.createServer((req,res)=>{
    if(req=="/favicon"){
        res.writeHead(200,{"Content-Type":"text/html"})
        res.write();
        res.end();
    }else if(req=="/"){
        let htmlContent=fs.readFileSync("./index.html","utf-8");
        res.writeHead(200,{"Content-Type":"text/html"})
        res.write(htmlContent.replace("{compname}",compname).replace("{compname}",compname).replace("{compname}",compname).replace("{compname}",compname));
        res.end();
    }else{
        fs.readFile("./"+req.url,"utf-8",function(error,data){
            if(error){
                res.writeHead(404,{"Content-Type":"text/html"})
                res.end("<h1> 404:Cannot find file</h1>")
            }else{
                res.writeHead(200,{"Content-Type":"text/html"})
                res.end(data.replace("{compname}",compname).replace("{compname}",compname).replace("{compname}",compname).replace("{compname}",compname));
            }
        })
    }
})

server.listen(2020,"localhost",function(error){
    if(error){
        console.log("error",error);
    }
})