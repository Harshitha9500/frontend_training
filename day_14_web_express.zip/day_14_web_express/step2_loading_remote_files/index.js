const axios=require("axios")
const fs=require("fs")

axios.get("https://www.valtech.com/en-in/").then(res=>fs.writeFileSync("temp/temp.html",res.data,"utf-8")).catch(function(error){
    console.log("error",error)
})