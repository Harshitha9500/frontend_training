<template>  
    <div>
      <pre>{{ JSON.stringify(users,null,1) }}</pre>
      <button @click="getUsers">Get Data</button>
      <h3 v-for="(user,key) in users" v-bind:key="key">{{user}}</h3>
    </div>
  </template>
  
  <script>
  import axios from "axios";
    export default {
     name : "AppUsers",
      data(){
        return {
          users : []
        }
      },
      methods : {
       getUsers(){
          axios.get("https://reqres.in/api/users?page=2")
          .then( res => this.users = res.data.data )
          .catch( err => console.log( err ))
      
      }
    }
}
  </script>
  
  <style>
 
  </style>