<template>
    <div>
        <h1>{{title}}</h1>
        <h3>{{power}}</h3>
        <button v-show="show" @click="power++">Increase Power</button>
        <h3>{{message}}</h3>
    </div>
</template>
<script>
    export default{
        data(){
            return{
                title:"Avnger's Power",
                power:6,
                message:"Hero is not ready to fight",
                show:true
            }
        },
        watch:{
            // power(npower){
            //     console.log(npower)
            //     if(npower>=5){
            //         this.message="Hero is ready to fight"
            //     }
            //     if(npower>=10){
            //         this.show=false
            //     }
            // }

            power:{
                handler(npower){
                    if(npower>=5){
                        this.message="Hero is ready to fight"
                    }
                },
                immediate:true
            }
            
        }
    }
</script>
<style></style>