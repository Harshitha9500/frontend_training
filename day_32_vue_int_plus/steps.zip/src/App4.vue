<template>
    <div>
      <AppHero details="details about batman comes here " title="Batman" :power="7" photo="http://tooncrush.com/valtech/batman.jpg" />
      <AppHero details="details about batman comes here " title="Batman" :power="7" photo="http://tooncrush.com/valtech/batman.jpg" />
      <img :src="herophoto" >
    </div>
  </template>
  <script>
  import AppHero from "./components/homeimage.vue";
   
  export default{
    data(){
      return {
        power : 0,
        appversion : 10,
        herophoto :  require('./assets/images/antman.jpg')
      }
    },
    components :{
      AppHero
    }
  }
  </script>
  <style></style>