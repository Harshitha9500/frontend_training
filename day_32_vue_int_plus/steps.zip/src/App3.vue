<template>
    <div>
        <HomeComp :version="appversion" title="Avengers" />
        <HomeComp :version="appversion" title="Justice League"/>
        <HomeComp :version="appversion" title="Indic Heros"/>
    </div>
</template>

<script>
import HomeComp from "./components/home.vue"
export default{
    data(){
        return {
            power:0,
            appversion:10
        }
    },
    components:{
        HomeComp
    }

}
</script>

<style></style>