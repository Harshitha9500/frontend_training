<template>
    <div>
      <FamGrand/>
    </div>
  </template>
  <script>
  import FamGrand from "./components/grand.vue";
   
  export default{
    data(){
      return {
      
      }
    },
    components :{
      FamGrand
    }
  }
  </script>
  <style></style>