<template>
    <div>
        <h3>Tile : {{title}} Version : {{version}}</h3>
    </div>

</template>

<script>
export default{
    name:"HomeComp",
    props:["title","version"]
}
</script>

<style></style>