import {BrowserRouter,Routes,Route,NavLink} from "react-router-dom";
import DetailsComp from "./details.component";
import hero from "./data.json";
import HomeComp from "./home.component";

function App(){
    return (
        <div>
            <h1>Heros List</h1>

            <BrowserRouter>              
            <Routes>
                <Route> 
                    <Route path="/" element={<HomeComp/>}/>
                    <Route path="/details/:id" element={<DetailsComp/>}/>
                </Route>
            </Routes>
            </BrowserRouter>
        </div>
    )
}

export default App;