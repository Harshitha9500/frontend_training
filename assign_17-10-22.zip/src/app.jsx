import {BrowserRouter,Routes,Route,NavLink} from "react-router-dom";
import DetailsComp from "./details.component";
import hero from "./data.json";

function App(){
    return (
        <div>
            <h1>Heros List</h1>

            <BrowserRouter>
              {
                            hero.heroes.map((val,idx)=>{
                                return <ul>
                                             <li><NavLink to={"/details/"+val.id}>{val.name}</NavLink></li>
                                        </ul>
                           })
              }
           
            <Routes>
                <Route> 
                    <Route path="/details" element={<DetailsComp/>}/>
                    <Route path="/details/:id" element={<DetailsComp/>}/>
                </Route>
            </Routes>
            </BrowserRouter>
        </div>
    )
}

export default App;