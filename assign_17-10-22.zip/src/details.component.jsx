import {BrowserRouter, Routes, Route, useParams, NavLink} from "react-router-dom"
import hero from "./data.json";
function DetailsComp(){
    let params=useParams();
    let hid=params.id;
    console.log(hid);
    return(
        <div>
            {            
                hero.heroes.map((val,idx)=>{
                    if(val.id===hid){
                        return  <div>
                                    <h1>Heros Details</h1>

                                    Name : {val.name}<br/><br />
                                    <b>PowerStats</b> <br />
                                    Intelligence : {val.powerstats.intelligence} <br />
                                    Power : {val.powerstats.power} <br />
                                    Speed : {val.powerstats.speed} <br />
                                    Strength : {val.powerstats.strength} <br /><br />

                                    <b>Biography</b> <br />
                                    Full-Name : {val.biography["full-name"]}<br/>
                                    Birth-Place : {val.biography["place-of-birth"]}<br/>
                                    Publisher : {val.biography.publisher}<br/><br />

                                    <b>Apperance </b> <br />
                                    Gender : {val.appearance.gender}  <br />
                                    Eye-Color : {val.appearance["eye-color"]}  <br />
                                    Height : {val.appearance.height[0]} &nbsp; {val.appearance.height[1]} <br />
                                    Weight : {val.appearance.weight[0]} &nbsp; {val.appearance.weight[1]} 
                                </div>
                            
                
                        
                    }
                    

            })}

            
        </div>
    )
}

export default DetailsComp;