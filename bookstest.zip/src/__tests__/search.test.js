import {fireEvent, render,screen} from '@testing-library/react';
import {} from '@testing-library/jest-dom';
import Search from '../components/search.component';
import userEvent from '@testing-library/user-event'
import { Provider } from "react-redux";
import store from "../redux/store";

describe("Test search component",()=>{
    test("render search with one button",async ()=>{
        render( <Provider store={store}>
            <Search />
        </Provider>);
        const buttonList=await screen.findAllByRole("button");
        expect(buttonList).toHaveLength(1);
    })

    test("college search should be type text",()=>{
        render( <Provider store={store}>
            <Search />
        </Provider>);
        const college=screen.getByPlaceholderText("Search By College")
        expect(college).toHaveAttribute("type","text");
    })

    test("book search should be type text",()=>{
        render( <Provider store={store}>
            <Search />
        </Provider>);
        const book=screen.getByPlaceholderText("Search By Book")
        expect(book).toHaveAttribute("type","text");
    })

    test("validation for empty fields",()=>{
        render( <Provider store={store}>
            <Search />
        </Provider>);
        const submitBtn=screen.getByTestId("submit");



        // const collegeInputNode=screen.getByPlaceholderText("Search By College");
        // const bookInputNode=screen.getByPlaceholderText("Search By Book");

        // userEvent.type(collegeInputNode,"");
        // userEvent.type(bookInputNode,"");

        
        
        userEvent.click(submitBtn);
        userEvent.click(submitBtn);
        
        const collegeVal=screen.getByText("Please Enter College")
        const bookVal=screen.getByText("Please Enter Book")

        expect(collegeVal).toBeInTheDocument();
        expect(bookVal).toBeInTheDocument();

       
    })

    test("validation",()=>{

        render( <Provider store={store}>
            <Search />
        </Provider>);
        const college=screen.getByTestId("collegeval").textContent;
        // const colval = college[0].children
        const submitBtn=screen.getByTestId("submit");
        // console.log(college)

        fireEvent.click(submitBtn)
        
        console.log(college)

        expect(college).toBe("")

        
    })
})