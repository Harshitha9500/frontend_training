import {createReducer,on} from '@ngrx/store';

import { search } from './search.actions';

export const initialState={
    books:{bookName:""},
    colleges:{collegeName:""}
}

const _searchReducer=createReducer(
    initialState,
    // on(search,(state,action)=>state.colleges=action.payload.colName)
)
export function searchReducer(state,action){
    return _searchReducer(state,action)
}