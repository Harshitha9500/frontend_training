import { Component,OnInit } from '@angular/core';
import book from './details.json';
import * as moment from 'moment'

interface Data{
      tags: string[],
      likes: string[],
      createdAt: string,
      _id: string,
      title: string,
      number: string,
      college: string,
      year: string,
      branch: string,
      selectedFile: string,
      name: string,
      email: string,
      creator: string,
      __v: number
}
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  bookData:Data[]=book.data
  m;
  constructor(){

  }
  ngOnInit(){
    this.m=moment
  }
}
