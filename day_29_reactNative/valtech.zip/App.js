import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import { SafeAreaView, StyleSheet, View } from 'react-native';
import Mainapp from './components/main';
import UserApp from './components/user';
 
export default function App() {
  let [state, setState] = useState('default title');
  let changeState = (args)=>{
    setState(args);
  }
  return (
   <SafeAreaView style={styles.container}>
    <StatusBar style="auto" />
    {/* <View style={ [styles.nestedbox,{
      backgroundColor:state
   }]}>
      <Mainapp changeState={changeState} title={ state }/>
      
    </View> */}
    <UserApp></UserApp>
   </SafeAreaView>
  );
}
 
const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop : 30,
    width : '100%'
  },
  nestedbox : {
    backgroundColor : 'silver',
    flex : 1
  }
});































// import { StatusBar } from 'expo-status-bar';
// import { Button, Pressable, StyleSheet, Text, View } from 'react-native';

// export default function App() {
//   return (
//     <View style={styles.container}>
//       <View style={[styles2.container,{
//         }]}>
//         <Text style={{fontSize:20,paddingLeft:10}}>Home</Text>
//         <Text style={{paddingLeft:50,fontSize:20}}>Valtech Heroes</Text>
//         <Text style={{paddingLeft:50,fontSize:20}}>Navigations</Text>
//       </View>
//       <View style={styles3.container}>
//         <Button title="BATMAN"></Button>
//         <Text></Text>
//         <Button title="ANTMAN"></Button>
//         <Text></Text>
//         <Button title="SUPERMAN"></Button>
//         <Text></Text>
//         <Button title="WONDER WOMAN"></Button>
//         <Text></Text>
//         <Button title="HULK"></Button>
//         <Text></Text>
//       </View>
//     </View>

//   );
// }

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     flexDirection:'column',
//     paddingTop:50
//   },
// });
// const styles2 = StyleSheet.create({
//   container: {
//     flexDirection:'row',
//     marginTop:50
//   },
// });
// const styles3 = StyleSheet.create({
//   container: {
//     flexDirection:'column',
//     margin:50
//   },
// });
