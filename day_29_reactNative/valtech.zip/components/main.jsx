import { Button, Text, View, StyleSheet } from "react-native"
 
let Mainapp = (props)=>{
    return  <View>
                <Text style={ compstyle.textStyle }>{ props.title }</Text>
                <Button onPress={()=> props.changeState('#FB5607')} title="click me to see magic" />
            </View>
}
 
let compstyle = StyleSheet.create({
    textStyle : {
        fontFamily : "sans-serif",
        fontSize : 24,
        color : 'white'
    }
})
export default Mainapp