import { Button, Image, StyleSheet, Text, View } from "react-native";
import axios from "axios";
import { useState } from "react";

let UserApp=()=>{
    let [heros,setHeros] = useState([]);
    let getData=()=>{
        axios.get("https://reqres.in/api/users?page=2").then(res=>{ setHeros(res.data.data)}).catch(error=>console.log(error))        
    }

    return (
        <View>
        {
        heros.map((val,idx)=>{
            return <View style={styles.container}>
            <Image source={{uri:val.avatar,width:50,height:50}}></Image>
            <Text style={styles.textContainer}>First Name : {val.first_name}</Text>
            <Text style={styles.textContainer}>Last Name : {val.last_name}</Text>
            <Text style={styles.textContainer}>Email : {val.email}</Text>          
            </View>
        })
}
        <Button onPress={()=>getData()} title="Click me"></Button>
        </View>
    )
}
const styles=StyleSheet.create({
    container:{
        margin:10,
        fontSize:30,
        paddingTop:10
    },
    textContainer:{
        fontSize:20
    },
    
})

export default UserApp;