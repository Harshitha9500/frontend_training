const configure=require("@reduxjs/toolkit").configureStore;
const heroReducer=require("../features/hero/heroSlice");
const movieReducer=require("../features/movie/movieSlice")

const store=configure({
    reducer:{
        hero:heroReducer,
        movie:movieReducer
    }
})

module.exports=store