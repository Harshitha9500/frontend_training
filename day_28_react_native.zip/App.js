//Assignment3
import { useState } from "react";
import ironman from "./assets/images/ironman.jpg"
import spiderman from "./assets/images/spiderman.jpg"
import hulk from "./assets/images/hulk.jpg"
import antman from "./assets/images/antman.jpg"
import { Button, Text,View,StyleSheet, Platform,Image } from "react-native";
export default function App(){

  let [name,updateName] = useState({title:'',image:''})
  let changeImage=( img )=>{
    if(img ==="ironman"){
      updateName({
        title:"Ironman",
        image:ironman
      })
    }
    else if(img ==="antman"){
       updateName({
        title:"Antman",
        image:antman
      })
    }
    else if(img ==="hulk"){
      updateName({
        title:"Hulk",
        image:hulk
      })
    }
    else{
      updateName({
        title:"Spiderman",
        image:spiderman
      })
    }
  }
  return(    
    <View style={mystyle.viewstyle}>
      <View>
        <Text style={{fontSize:42}}>Avengers</Text>
      </View>
      <Text/>
      <View>
        <Text style={{fontSize:22}}>
        Title : {name.title}  
        </Text>
        <Image source={name.image}></Image>
      <View>
        <Text></Text>
        <Button onPress={()=>changeImage("antman")} title="Antman"></Button><Text></Text>
        <Button onPress={()=>changeImage("ironman")} title="Ironman"></Button><Text/>
        <Button onPress={()=>changeImage("spiderman")} title="spiderman"></Button><Text></Text>
        <Button onPress={()=>changeImage("hulk")} title="hulk"></Button><Text></Text>
        <Text/>
      </View>
      </View>

     </View>
   
  )
}
let mystyle = StyleSheet.create({
  viewstyle:{
    flex:1,
    padding:50,
    paddingTop: Platform.OS ==="android"?50:0
  }
})