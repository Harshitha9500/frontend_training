import {createAction,props} from '@ngrx/store';

export const search=createAction('search(college,book)',props<{payload:{colName:string, bookName:string}}>)