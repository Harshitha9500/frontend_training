import { Component } from '@angular/core';
import bookData from './details.json'
@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css']
})
export class ContentComponent {
  college:string="";
  book:string="";
  searchResults:object;
  subBooks:string[];
  funcCollege(val){
      this.college=val;
      console.log(this.college)
  }
  funcBook(val){
    this.book=val;
  } 
  filtering(){
    for(let item of bookData.data){
      console.log(item._id);
      if(this.book==item.name || this.college==item.college){
        this.subBooks.push(item._id);
      }
    }

      console.log(this.subBooks[0]);
    return this.subBooks;
  }


}
