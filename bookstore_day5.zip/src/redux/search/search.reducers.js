import { SEARCH_BOOK,GET_BOOK } from "./search.types"


const initialstate={
    isLoading: true, 
    books: [{bookName:'Anmol'}]
}

let searchReducer=(state=initialstate,action)=>{
    switch(action.type){
        case SEARCH_BOOK : return {
            ...state, 
            books:[{
                bookName:[action.payload.book]
            }]
        }
        case GET_BOOK:return{
            ...state
        }
        // case SEARCH_COLLEGE : return {...state, BooksState:state.numOfHeros-1}
        default : return state
    }
}

export {searchReducer}