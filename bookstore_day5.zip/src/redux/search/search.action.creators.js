import { SEARCH_BOOK, SEARCH_COLLEGE,GET_BOOK } from "./search.types"

const searchbook=(book)=>{
    return{
        type:SEARCH_BOOK,
        payload:{book}
    }
}
const searchcollege=()=>{
    return{
        type:SEARCH_COLLEGE
    }
}
const getbook=()=>{
    return{
        type:GET_BOOK
    }
}

export {searchbook,searchcollege,getbook}