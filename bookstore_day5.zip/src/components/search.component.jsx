import {useSelector, useDispatch} from "react-redux"
import { searchbook } from "../redux/";
let Search = ()=>{
  // let bookStore = useSelector(state => state.search.bookStore);
var book=''
let books = useSelector(state => state.search.books);
// let searchByCollege = useSelector(state => state.search.searchByCollege);
var bookSearch =[]

Object.keys(books).forEach(function(item){
  bookSearch.push(books[item]);

 });
  let dispatch = useDispatch();
  let setBook=(e)=>{

    book=e.target.value

    



  }

    return <div id="searchbox">
     
     <div>
  <div class="mb-1">
    <label for="college"  class="form-label"></label>
    <input  placeholder="Search By College" type="text" class="form-control" id="college" name="college"/>
    <span style={{color:"red", margin:"0px"}}>Please Enter College</span>
  </div>
  <div class="mb-2">
    <label for="book" class="form-label"></label>
    <input placeholder="Search By Book" onChange={(e)=>setBook(e)} type="text" class="form-control" id="book" name="book"/>
  <span style={{color:"red", margin:"0px"}}>Please Enter Book</span>
  </div>
  <button type="submit" onClick={()=>dispatch(searchbook(book))} class="btn btn-primary">Submit</button>
</div>
</div>
}

export default Search;