import { Component } from '@angular/core';

@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css']
})
export class ContentComponent {
  college:string="";
  book:string="";
  funcCollege(val){
      this.college=val;
  }
  funcBook(val){
    this.book=val;
  }

}
