import { Search } from "../entity/search";
import { createReducer,on } from "@ngrx/store";
import { search } from "./search.action";

export const initialEntry:Search[]=[];

export const searchReducer=createReducer(
    initialEntry,
    on(search,(entries,searches)=>{
        const entriesClone:Search[]=JSON.parse(JSON.stringify(entries));
        entriesClone.push(searches);
        return entriesClone;
    })
)