export interface Search {
    collegeName:string;
    bookName:string;
}