const express=require("express");
const cors=require("cors");
const mongoose=require("mongoose");
let errorHandler=require("./utils").errorHandler;
const config=require("./config.json");


//configuration for express
let app=express();
let Schema=mongoose.Schema;
let ObjectId=Schema.ObjectId;
let port=process.env.PORT || config.port;

let Hero=mongoose.model("Hero",Schema({
    id:ObjectId,
    title:String,
    firstname:String,
    lastname:String

}));

let dbstring=`mongodb+srv://${config.user}:${config.password}@cluster0.rk5sld5.mongodb.net/${config.dbname}?retryWrites=true&w=majority`;
mongoose.connect(dbstring)
.then(res=>{console.log("db connected")})
.catch(err=>errorHandler);

app.use(express.json());
app.use(express.static(__dirname+"/public"));



//READ
app.get("/data",(req,res)=>{
    Hero.find().then(dres=>{
        res.json(dres);
    })
});

// setTimeout(()=>{
//     let hero=new Hero({
//         title:"spiderman",
//         firstname:"peter",
//         lastname:"panther"
//     })
//     hero.save()
//     .then(res=>console.log("db updated"))
//     .catch(err=>console.log("Error",err))
// },2000)

//CREATE
app.post("/data",(req,res)=>{
    let hero=new Hero(req.body)
    hero.save()
    .then(res=>{
        res.send({message : "hero added to list"})
        console.log("db updated");
    })
    .catch(err=>console.log("Error",err))
})

// setTimeout(()=>{
//     Hero.findByIdAndUpdate({_id:'633a8e4fb0f3c163e475576a'})

// }
// )

//UPDATE
app.post("/update/:hid",(req,res)=>{
    Hero.findByIdAndUpdate({_id:req.params.hid})
    .then(dbres=>{
        dbres.title=req.body.title;
        dbres.firstname=req.body.firstname;
        dbres.lastname=req.body.lastname;
        dbres.save().then(updateRes=>res.send({message:"hero info updated"}))
    })

})

//READ UPDATE
app.get("/edit/:heroid",(req,res)=>{
    Hero.findById({_id:req.params.heroid})
    .then(dbres=> {
            res.send(dbres)
    })
});


//DELETE
app.delete("/delete/:hid",(req,res)=>{
    Hero.findByIdAndDelete({_id:req.params.hid})
    .then(dbres=>res.send({message:"hero deleted",hero:dbres.title}))
})

app.listen(port,config.host,errorHandler);
console.log(`Server is now live on : ${port}`);