import { ActionReducerMap } from "@ngrx/store";
import { cartReducer, CartState } from "../cart/store/cart.reducer";

export interface appState{
cart: CartState
}

export const reducers: ActionReducerMap<appState> = {
    cart: cartReducer
}