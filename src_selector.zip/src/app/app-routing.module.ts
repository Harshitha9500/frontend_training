import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FirstComponentComponent } from './first-component/first-component.component';

const routes: Routes = [
  {
  path:'firstpage',
  component:FirstComponentComponent
},
{
  path:'products',
  loadChildren: () => import('./product/product.module').then(m => m.ProductModule)
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
