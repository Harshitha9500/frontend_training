import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FirstComponentComponent } from './first-component/first-component.component';
import { HeaderComponent } from './components/header/header.component';
import { HttpClientModule } from '@angular/common/http';
import { CartListComponent } from './cart/components/cart-list/cart-list.component';
import { StoreModule } from '@ngrx/store';
import { reducers } from './store/index.reducers';
import {StoreDevtoolsModule} from "@ngrx/store-devtools";
@NgModule({
  declarations: [
    AppComponent,
    FirstComponentComponent,
    HeaderComponent,
    CartListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    StoreModule.forRoot(reducers),
    StoreDevtoolsModule.instrument({maxAge:100})
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
