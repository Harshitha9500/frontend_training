import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Product } from '../interfaces/product.inerface';
import {Observable} from 'rxjs'
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ProductListService {

  constructor(private http: HttpClient) { }

  getProducts():Observable<Product[]>{
   return this.http.get(`${environment.apiBasePath}/api/products`) as any;
  }
    
  
}
