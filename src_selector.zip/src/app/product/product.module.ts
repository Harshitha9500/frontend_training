import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductListComponent } from './product-list/product-list.component';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';


const productRoutes: Routes = [{
  path:'',
  component:ProductListComponent
}];


@NgModule({
  declarations: [
    ProductListComponent,
    
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(productRoutes),
    HttpClientModule
  ]
})
export class ProductModule { }
