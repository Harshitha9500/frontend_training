export interface Product{
    brandId?:number;
    camera?:string;
    cpu?:string;
    display?:string;
    gpu:string;
    id:number;
    name:string;
    os:string;
    price:number;
    ram:string;
    release:string;
    size:string;
    storage:string;
    weight:string;
    year:number
  }