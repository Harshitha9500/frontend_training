import { Component,OnInit } from '@angular/core';
import { ProductListService } from '../services/product-list.service';
import { Product } from '../interfaces/product.inerface';
import { CartService } from 'src/app/cart/services/cart.service';
import { appState } from 'src/app/store/index.reducers';
import {Store} from '@ngrx/store'
import { CartActions } from 'src/app/cart/store/cart.actions';



@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  productData: Product[]=[] ;

  constructor(private productListService:ProductListService, private cartService:CartService, private store: Store<appState>){

  }
  ngOnInit(): void {
    this.productListService.getProducts().subscribe(productInfo=>{
      this.productData=productInfo
      console.log(this.productData);
    })
  }
  addProductToCart(product: Product, quantity: string): void{
    console.log(product.name,quantity)
    const qtyInNumber=Number(quantity)
    // this.cartService.addProductToCart(product,quantity)
    this.store.dispatch(CartActions.addProduct({
      product: product,
      quantity: qtyInNumber
  })
    )
}
}
