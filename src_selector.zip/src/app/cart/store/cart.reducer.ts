import { Product } from "src/app/product/interfaces/product.inerface";
import {createReducer, on, Action} from '@ngrx/store'
import { CartActions } from "./cart.actions";

export interface CartEntry{

    product: Product,
    quantity: number;
}

export interface CartState{

    cartEntries: CartEntry[]
}

export const cartInitialState: CartState={
    cartEntries:[]
}

const reducer = createReducer(cartInitialState,
     on(CartActions.addProduct, (state, action)=>{
    const newEntry = {
        product: action.product,
        quantity: action.quantity
    }
    return {
        ...state,
        cartEntries: [...state.cartEntries, newEntry]
    }
})
)

export function cartReducer(state: CartState | undefined,action :Action): CartState{
 
    return reducer(state,action)
}