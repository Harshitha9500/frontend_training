import { createSelector } from "@ngrx/store";
import { appState } from "src/app/store/index.reducers";
import { CartState } from "./cart.reducer";

const feature=(state:appState)=>state.cart

export namespace CartSelector{
    export const entries=createSelector(feature,(state:CartState)=>{
        return state.cartEntries
    })
    export const firstEntry=createSelector(feature,(state:CartState)=>{
        return state.cartEntries[0];
    })
}