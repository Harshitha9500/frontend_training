import {createAction,props} from '@ngrx/store'
import { Product } from 'src/app/product/interfaces/product.inerface'

interface addProduct{
    product: Product,
    quantity: number
}

export namespace CartActions{


    export const addProduct = createAction('[Cart] add product to cart', props<addProduct>())
}