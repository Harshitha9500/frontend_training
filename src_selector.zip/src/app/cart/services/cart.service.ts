import { Injectable } from '@angular/core';
import { Product } from 'src/app/product/interfaces/product.inerface';


export interface cartEntry {
  product: Product;
  quantity: number;
}
@Injectable({ providedIn: 'root' })

export class CartService {

  cartEntries: cartEntry[] = [];

  constructor() {}
  
  addProductToCart(product: Product, qty: number) {

    const existingProduct = this.cartEntries.find((cartEntry)=>{
        return cartEntry.product.id===product.id
    })
    
    if(existingProduct){
      existingProduct.quantity=qty;
    }else{

      this.cartEntries.push({
        product: product,
        quantity: qty
      })
    }
    console.log(this.cartEntries)
  }
}
