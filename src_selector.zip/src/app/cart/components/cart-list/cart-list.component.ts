import { Component } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { appState } from 'src/app/store/index.reducers';
import { cartEntry, CartService } from '../../services/cart.service';
import { CartSelector } from '../../store/cart.selectors';

@Component({
  selector: 'app-cart-list',
  templateUrl: './cart-list.component.html',
  styleUrls: ['./cart-list.component.css']
})
export class CartListComponent {

  cartEntries$: Observable<cartEntry[]>


    constructor(private myCartService: CartService,private store:Store<appState>){
      this.cartEntries$ = this.store.pipe(select(CartSelector.entries))
    }

    getCartEntries(){
      return this.myCartService.cartEntries;
    }
}
