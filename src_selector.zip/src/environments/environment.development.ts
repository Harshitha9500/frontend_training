export const environment = {
    apiBasePath:'http://localhost:7070'
};
