export const environment = {
    apiBasePath:'http://www.myapi.com'
};
