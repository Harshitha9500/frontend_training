import { Component } from "react";
import ChildComp from "./child_component";

class App extends Component{
    render(){
        return <div>
            <ChildComp title="first component" ></ChildComp>
        </div>
    }
}

export default App;