import { Component } from "react";
import ChildComp from "./child_component";
import PureChildComp from "./child_pure_component";

class App extends Component{
     //state is an object
     state={
        title:"Default Title",
        power:0,
        version:0
    }

    increasePower=()=>{
        this.setState({
            power:this.state.power+1
        })
    }

    setPowerTo100=()=>{
        this.setState({
            version:100
        })
    }
    render(){
        return <div>
            <h1>Welcome to your life</h1>
            <button onClick={this.increasePower}>Change Power</button>
            <button onClick={this.setPowerTo100}>Set Version</button>
            <ChildComp version={this.state.version} power={this.state.power}></ChildComp>
            <PureChildComp version={this.state.version} power={this.state.power}/>
        </div>
    }
}

export default App;