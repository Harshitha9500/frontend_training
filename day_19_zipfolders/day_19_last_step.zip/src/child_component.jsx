import { Component} from "react";

class ChildComp extends Component{
   
    render(){
        console.log("Component rendered "+Math.random())
        return <div>
                    <h2>Child Component | Power : {this.props.power} | Version : {this.props.version}</h2>
                </div>
    }
}

export default ChildComp;