import { Component } from "react";

// class Hero extends Component{
//     render(){
//         return <div>
//                 <h2>{this.props.children}</h2>
//         </div>
//     }
// }

class Hero extends Component{
    rating=25;
    render(){
        return <div>
                <h2>{this.props.title+" | version : "+(this.props.version)}</h2>
                <h3>Rating : {this.rating}</h3>
                <ol>{
                        this.props.list.map((val,idx)=>{
                            return <li key={idx}>{val}</li>
                        })
                    }
                </ol>
                <button onClick={()=>{this.rating=this.rating+1;console.log(this.rating);this.forceUpdate()}}>Change version</button>
        </div>
    }
}

export default Hero;