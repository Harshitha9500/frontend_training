import { Component } from "react";
import Hero from "./hero";

// class App extends Component{
//     render(){
//         return <div>
//                     <Hero>Avengers</Hero>
//                     <Hero>Justice League</Hero>
//                     <Hero>Indic Heroes</Hero>
//                 </div>
//     }
// }

class App extends Component{
    avengers=['ironman','thor']
    justiceLeague=['wonder woman','antman']
    indicHeros=['krish','shaktiman']
    render(){
        return <div>
                    <Hero list={this.avengers} version={1} title="Avengers"></Hero>
                    <Hero list={this.justiceLeague} version={2} title="Justice Leauge"></Hero>
                    <Hero list={this.indicHeros} version={3} title="Indic Heroes"></Hero>
                </div>
    }
}

export default App;