import { Component } from "react";
import ChildComp from "./child_component";
import PureChildComp from "./child_pure_component";

class App extends Component{
    render(){
        return <div>
            <h1>Welcome to your life</h1>
            <ChildComp title="first component" ></ChildComp>
            <PureChildComp/>
        </div>
    }
}

export default App;