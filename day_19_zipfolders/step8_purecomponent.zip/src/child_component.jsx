import { Component} from "react";

class ChildComp extends Component{
    //state is an object
    state={
        title:"Default Title",
        power:0,
        version:0
    }

    increasePower=()=>{
        this.setState({
            power:this.state.power+1
        })
    }

    setPowerTo100=()=>{
        this.setState({
            version:100
        })
    }
    render(){
        console.log("Child Component rendered "+Math.random())
        return <div>
                    <h2>Child Component | Power : {this.state.power} | Version : {this.state.version}</h2>
                    <button onClick={this.increasePower}>Change Power</button>
                    <button onClick={this.setPowerTo100}>Set Version</button>
                </div>
    }
}

export default ChildComp;