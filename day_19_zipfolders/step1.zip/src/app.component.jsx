// function App(){
//     return <h1>Have a nice day!!</h1>
// }

// export {App}

class App extends Component{
    render(){
        return <h1>Welcome to valtech</h1>
    }
}
export default App;