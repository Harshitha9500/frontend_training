import { Component } from "react";
import PropTypes from "prop-types";

class ChildComp extends Component{
    // static defaultProps={
    //     title:"default title",
    //     version:0,
    //     power:0
    // }
    
    static propTypes={
        title:PropTypes.string.isRequired,
        version:PropTypes.number.isRequired,
        power:PropTypes.number.isRequired
    }

    render(){
        return <div>
                    <h2>Title : {this.props.title}</h2>
                    <h3>Version : {this.props.version}</h3>
                    <h4>Power : {this.props.power}</h4>
                </div>
    }
}
// ChildComp.defaultProps={
//     title:"default title",
//     version:0,
//     power:0
// }

export default ChildComp;