import { Component } from "react";
import ChildComp from "./child_component";

class App extends Component{
    render(){
        return <div>
            <ChildComp title="first component" ></ChildComp>
            <ChildComp title="second component" version={2} power={6}></ChildComp>
            <ChildComp title="third component" version={3} power={7}></ChildComp>
        </div>
    }
}

export default App;