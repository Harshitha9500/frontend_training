import { SEARCH_BOOK, SEARCH_COLLEGE } from "./hero.types"
import data from "../data/details.json"

const initialstate={
    BooksState: data
}

let searchReducer=(state=initialstate,action)=>{
    switch(action.type){
        case SEARCH_BOOK : return {...state, BooksState:state.BooksState}
        case SEARCH_COLLEGE : return {...state, BooksState:state.numOfHeros-1}
        default : return state
    }
}

export {heroReducer}