import { SEARCH_BOOK, SEARCH_COLLEGE } from "./search.types"

const searchbook=(book)=>{
    return{
        type:SEARCH_BOOK,
        payload:{book}
    }
}
const searchcollege=(college)=>{
    return{
        type:SEARCH_COLLEGE,
        payload:{college}

    }
}


export {searchbook,searchcollege}