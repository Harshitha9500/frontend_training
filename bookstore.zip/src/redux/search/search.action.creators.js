import { SEARCH_BOOK, SEARCH_COLLEGE } from "./search.types"

const searchbook=()=>{
    return{
        type:SEARCH_BOOK
    }
}
const searchcollege=()=>{
    return{
        type:SEARCH_COLLEGE
    }
}

export {searchbook,searchcollege}