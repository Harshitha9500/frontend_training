import background from "../assets/background.jpg"
import book from "../data/details.json"
let List = () =>{
  let data = book.data;
    return <div id="ahwp">
      <div className="row row-cols-1 row-cols-md-4 g-4">
    
      {
        data.map((val,idx)=>{
          return <div className="col" >
          <div className="card" >
          <div id="backcard">
          <img src={background} className="card-img-top" alt="book" />
          <div id="cardName">{val.name}</div>
          <div id="cardDate">
            <span>X months ago</span>
          </div>
          </div>
      <div className="card-body" id="cardback">
        <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      </div>
      <ul className="list-group list-group-flush">
        <li className="list-group-item">An item</li>
        <li className="list-group-item">A second item</li>
        <li className="list-group-item">A third item</li>
      </ul>
      <div className="card-body">
        <span>Like</span>
      </div>
    </div>
    </div>
        })
      }
  </div>
  
  </div>
}

export default List