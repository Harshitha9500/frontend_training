let Search = ()=>{

    return <div id="searchbox">
     
     <form>
  <div class="mb-1">
    <label for="college"  class="form-label"></label>
    <input  placeholder="Search By College" type="text" class="form-control" id="college" name="college"/>
    <span style={{color:"red", margin:"0px"}}>Please Enter College</span>
  </div>
  <div class="mb-2">
    <label for="book" class="form-label"></label>
    <input placeholder="Search By Book" type="text" class="form-control" id="book" name="book"/>
  <span style={{color:"red", margin:"0px"}}>Please Enter Book</span>
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
}

export default Search