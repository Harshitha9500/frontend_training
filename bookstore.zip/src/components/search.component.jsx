import { useSelector, useDispatch } from "react-redux";
// import { NavLink } from "react-router-dom";
import { searchbook, searchcollege } from "../redux/";
let Search = () => {
  // let bookStore = useSelector(state => state.search.bookStore);
  var book = "";
  var college = "";
  let books = useSelector((state) => state.search.books);
  let colleges = useSelector((state) => state.search.colleges);
  // let searchByCollege = useSelector(state => state.search.searchByCollege);
  var bookSearch = [];
  var collegeSearch = [];

  Object.keys(books).forEach(function (item) {
    bookSearch.push(books[item]);
  });
  Object.keys(colleges).forEach(function (item) {
    collegeSearch.push(colleges[item]);
  });
  let dispatch = useDispatch();
  let setBook = (e) => {
    book = e.target.value;
    e.target.value=null
  };
  let setCollege = (e) => {
    college = e.target.value;
    e.target.value=null
  };

  return (
    <div id="searchbox">
      <div> 
        <div class="mb-1">
          <label for="college" class="form-label"></label>
          <input
            placeholder="Search By College"
            onBlur={(e) => setCollege(e)}
            type="text"
            class="form-control"
            id="college"
            name="college"
          />
          <span style={{ color: "red", margin: "0px" }}>
            Please Enter College
          </span>
        </div>
        <div class="mb-2">
          <label for="book" class="form-label"></label>
          <input
            placeholder="Search By Book"
            onBlur={(e) => setBook(e)}
            type="text"
            class="form-control"
            id="book"
            name="book"
          />
          <span style={{ color: "red", margin: "0px" }}>Please Enter Book</span>
        </div>
        {/* <NavLink to={"/search/"+book}> */}
        <button
          type="submit"
          onClick={() => dispatch(searchbook(book))}
          class="btn btn-primary"
        >
          Search
        </button>
        {/* </NavLink> */}
      </div>
    </div>
  );
};

export default Search;
