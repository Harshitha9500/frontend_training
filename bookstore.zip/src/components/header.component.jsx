import '../styles/style.css';
import bookicon from "../assets/Book.png"

let Header = ()=>{
        return <div id="container">
            <div id="bookhead">
                <h2>BuyBooks <img src={bookicon} alt="Logo" height={40} width={40}/></h2>
            </div>
        </div>
    
}

export default Header;
