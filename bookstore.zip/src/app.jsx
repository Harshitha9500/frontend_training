import { Component } from "react";
import {BrowserRouter,Routes,Route} from "react-router-dom";
import Details from "./components/details.component";

import Main from "./components/main.component";
import NotFound from "./components/not-found";

class App extends  Component{
    render(){
        return <div>
            <BrowserRouter>               
            <Routes> 
                <Route> 
                    <Route path="/" element={<Main/>}/>
                    <Route path="/details/:id" element={<Details/>}/>
                    {/* <Route path="/search/:book" element={<NotFound/>}/> */}
                </Route>
            </Routes>
            </BrowserRouter>     
        </div>
    }
}

export default App;