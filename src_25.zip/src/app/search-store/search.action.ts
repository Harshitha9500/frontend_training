import { createAction, props } from "@ngrx/store";
import { Search } from "../entity/search";

export const search=createAction('search book',props<Search>());