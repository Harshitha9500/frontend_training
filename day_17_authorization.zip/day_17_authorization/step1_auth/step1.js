const express=require("express");
const mongoose=require("mongoose");
const session=require("client-sessions");
const bcrypt=require("bcrypt")
let app=express();

app.use(express.urlencoded({extended:true}))
let Schema=mongoose.Schema;
let ObjectId=Schema.ObjectId;

app.use(session({
    cookieName:"valtech",
    secret:"jhdgfguheijfnsjbfdhasjdkjsid",
    duration:30*60*1000,
    activeDuration:10*60*1000,
    cookie:{
        ephemeral:true
    }
    
}))

let User=mongoose.model("User",new Schema({
    id:ObjectId,
    firstname:String,
    lastname:String,
    email:{type:String,unique:true},
    password:String
}));

let dbstring="mongodb+srv://admin:PkKmeqYPd5ipJmxN@cluster0.rk5sld5.mongodb.net/valtechdb?retryWrites=true&w=majority"
mongoose.connect(dbstring)
.then(res=>{console.log("db connected")})
.catch(err=>errorHandler);

app.get("/",(req,res)=>{
    res.render("home.pug")
})

app.get("/login",(req,res)=>{
    res.render("login.pug")
})

app.get("/register",(req,res)=>{
    res.render("register.pug")
})

app.get("/profile",(req,res)=>{
    if(req.valtech && req.valtech.user){
        User.findOne({email:req.valtech.user.email},function(err,user){
            if(!user){
                req.valtech.reset();
                res.redirect("/login")
            }else{
                res.render("profile.pug");
            }
        })
    }else{
        res.render("profile.pug")
    }
    
})

app.get("/logout",(req,res)=>{
    req.valtech.reset();
    res.redirect("/login")
})

app.post("/register",(req,res)=>{
    var hash=bcrypt.hashSync(req.body.password,bcrypt.genSaltSync(10))
    var user=new User({
        firstname:req.body.firstname,
        lastname:req.body.lastname,
        email:req.body.email,
        password:hash
    });
    user.save(function(error){
        let clienterror="";
        if(error){
            if(error.code===11000){
                clienterror="email id already registered";
            }else{
                clienterror="something went wrong";
                
            }
            res.render("register.pug",{clienterror})
        }else{
            res.redirect("/profile");
            console.log("user registered");
        }
    })
})

app.post("/login",(req,res)=>{
    User.findOne({email:req.body.email},function(error,user){
        if(error){
            res.render("login.pug",{
                error:"no credentials found"
            })
        }else{
            if(bcrypt.compareSync(req.body.password,user.password)){
                req.valtech.user=user;
                res.redirect("/profile");
            }else{
                res.render("login.pug",{
                    error:"password or email not correct"
                })
            }
        }
    })
})
app.listen(5656,"localhost",function(err){
    if(err){
        console.log("Error",err);
    }else{
        console.log("server is noe live on : 5656");
    }
})