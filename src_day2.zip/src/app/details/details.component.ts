import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import book from './details.json';


interface Data{
      tags: string[],
      likes: string[],
      createdAt: string,
      _id: string,
      title: string,
      number: string,
      college: string,
      year: string,
      branch: string,
      selectedFile: string,
      name: string,
      email: string,
      creator: string,
      __v: number
}

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit  {

  public detail:string;
  
  bookData:Data[]=book.data
  
  constructor(private route: ActivatedRoute){
  }
  ngOnInit(){
      this.route.params.subscribe((param : Params) => {
        this.detail = param['id'];
        console.log(this.detail)
    });
  }


  
}
