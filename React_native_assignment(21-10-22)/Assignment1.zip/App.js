//Assignment 1
import React from "react";
import { Platform, StyleSheet, Text, View } from "react-native";

export default function App(){
  return (
    <View style={[styles.container, {
      flexDirection: "column"
    }]}>
      <View style={{ flex: 2, backgroundColor: "#005f73" }}  >
        <Text style={{textAlign:"center",paddingTop:50,fontSize:50}}>Header</Text>
      </View>     
      <View style={{ flex: 5, backgroundColor: "#94d2bd" }} >
         <Text style={{textAlign:"center",paddingTop:150,fontSize:50}}>Content</Text>
      </View>
      <View style={{ flex: 3, backgroundColor: "#0a9396" }} >
        <Text style={{textAlign:"center",paddingTop:50,fontSize:50}}>Footer</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    
    paddingTop:Platform.OS ==="android"&&50 || Platform.OS==="ios"&&75
  },
});

