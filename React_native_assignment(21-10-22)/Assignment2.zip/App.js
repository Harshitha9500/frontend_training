//Assignment 2
import React, { useState } from "react";
import { Platform,Pressable, SafeAreaView, StyleSheet, Text, View } from "react-native";

export default function App(){
  let [color,setColor]=useState("")
  return (
    <View style={[styles.container,{
      alignItems:"stretch"
    }]}>
    <View style={[styles.container,{
          backgroundColor:color,
          }]}>
      <Pressable onPress={()=>setColor("#005f73")}>
          <View style={{  height:100,width:110, backgroundColor: "#005f73" }}  ></View>
      </Pressable>

      <Pressable onPress={()=>setColor("#94d2bd")}>
        <View style={{  height:100,width:110, backgroundColor: "#94d2bd" }} ></View>
      </Pressable> 
      
      <Pressable onPress={()=>setColor("#0a9396")}>
        <View style={{  height:100,width:110, backgroundColor: "#0a9396" }} ></View>
      </Pressable> 

      <Pressable onPress={()=>setColor("#335c67")}>
        <View style={{  height:100,width:110, backgroundColor: "#335c67" }} ></View>
      </Pressable> 
      </View>
    </View>
    
  );
};

const styles = StyleSheet.create({
  container: {
    flex:1,
    flexDirection:"row",
    alignItems : "flex-end",
    paddingTop:Platform.OS==="android"&&50 || Platform.OS==="ios"&&75
  
  },
});