import background from "../assets/background.jpg";
import like from "../assets/like.png"
import book from "../data/details.json";
import moment from "moment"
let List = () => {
  let data = book.data;
  return (
    <div id="ahwp">
      <div className="row row-cols-1 row-cols-md-4 g-4">
        {data.map((val, idx) => {
          return (
            <div className="col">
              <div className="card">
                <div id="backcard">
                  <img src={background} className="card-img-top" alt="book" />
                  <div id="cardName">{val.name}</div>
                  <div id="cardDate">
                    <span>{moment(val.createdAt).fromNow()}</span>
                  </div>
                </div>
                <div id="cardback">
                  <button
                    disabled="true"
                    type="button"
                    class="btn btn-light cardbtn"
                  >
                    College : {val.college}
                  </button>
                  <button type="button" class="btn btn-light cardbtn">
                    Year : {val.year}
                  </button>
                  <button type="button" class="btn btn-light cardbtn">
                    Branch : {val.branch}
                  </button>
                </div>

                <div id="price">
                  <h5>Rs. {val.title}/-</h5>
                </div>
                <div id="branch">
                  {val.tags.map((x, idx) => {
                    return (
                      <div id="bran">
                        {x} <br />
                      </div>
                    );
                  })}
                </div>
                <div className="likes">
                  <span> <img src={like} alt="like" width={25} height={25}/>
                  
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default List;
