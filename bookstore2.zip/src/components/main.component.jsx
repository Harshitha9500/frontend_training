import Content from "./content.component";
import Details from "./details.component";
import Header from "./header.component";

let Main = ()=>{
        return <div id="mainCont">
            <Header/>
            <Content/>
            <Details/>
        </div>
    
}

export default Main