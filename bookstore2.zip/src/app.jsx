import { Component } from "react";
import Main from "./components/main.component";

class App extends  Component{
    render(){
        return <div>
            <Main/>        
        </div>
    }
}

export default App;